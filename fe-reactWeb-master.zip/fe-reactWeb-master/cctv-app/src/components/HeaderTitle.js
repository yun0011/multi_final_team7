import classes from './HeaderTitle.module.css';

export default function HeaderTitle(props) {
    return (
        <header className={classes.title}>CCTV 모니터링</header>
    )
}